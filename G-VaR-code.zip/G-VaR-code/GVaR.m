
%%
%  Using the data S&P500 to verify our model G_VaR: 
%  sp.txt denotes the daily closing price of S&P500;
%  mean-sp.txt denotes the mean of data of the return of S&P500 based on AR model,
%  with the length of the historical data is 100;
%  n1=1000 is the large window W, denotes the length of historical data;
%  n2=[950 700 400 240 120] denotes the samll window W_0 related to risk level
%  alpha=[0.05 0.025 0.01 0.005 0.003]; 
%%
 clear all 
 clc
 tic
sp=load('sp.txt');% the data S&P500
sp1=diff(log(sp));% calculate the daily return of S&P500 
n=length(sp1);% the length of the return of S&P500
armean=load('mean-sp.txt');% load the mean value of S&P500, which was calculated by AR(1)model
sp2=sp1(101:n)-armean;% minus the mean value of the return of S&P500

n=length(sp2);% the length of sp2
n1=1000;% the length of historical data W
n2=[950 700 400 240 120];% the five small window W_0 related to risk level alpha
alpha=[0.05 0.025 0.01 0.005 0.003];% the five risk level
m=n-n1;% the number of predict date
G_VaR=[];% the VaR under nonlinear expectation 
num=zeros(5,1); 
sigmamax=zeros(m,1);
sigmamin=zeros(m,1);

%%
for p=1:5 % calculate the five risk level alpha=0.05 0.025 0.01 0.005 0.003
for k=1:m
sigma=zeros(n1-n2(p)+1,1);
for j=1:n1-n2(p)+1
sigma(j)=std(sp2(k+j-1:n2(p)+k+j-2));
end 
sig2=max(sigma); 
sig1=min(sigma);
a=icdf('Normal',alpha(p)*(sig1+sig2)/2/sig2,0,sig2);
G_VaR(k,p) = a+armean(n1+k); 
end


for q=n1+1:n1+m
  if sp2(q)+armean(q)<G_VaR(q-n1,p)
     num(p)= num(p)+1/m; 
  end
end
end


p=fopen('ngv1000.txt','a');%record the value of G_VaR
for i=1:m
fprintf(p,'%d,%d,%d,%d,%d\r\n',G_VaR(i,:));
end
fclose(p);

p=fopen('ngq1000.txt','a');%record the violation of G_VaR
fprintf(p,'%d,%d,%d,%d,%d\r\n',num);
fclose(p);
toc

plot(sp2(n1+1:n1+m)+armean(n1+1:n1+m))
hold on
plot(G_VaR,'r')
xlabel('Time');
legend('Confidence level');


